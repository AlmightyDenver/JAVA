package theD.begin.CAL;

import java.io.IOException;
import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) throws IOException {
		Scanner scanner = new Scanner(System.in);

		int input_a = 0;
		int input_b = 0;
		String op;
		int rslt = 0;

		System.out.print("���� �Է� : ");
		input_a = scanner.nextInt();

		do {
			System.out.print("������ �Է� (+. -, *, /) : ");
			op = scanner.next();
			// System.in.skip(2)�ʿ� X

		} while (!op.equals("+") && !op.equals("-") && !op.equals("/") && !op.equals("*"));
		// String�̶� != �ƴϰ� !a.equlas()���ؾ�

		System.out.print("���� �Է� : ");
		input_b = scanner.nextInt();

		switch (op) {
		case "+":
			rslt = Operator.plus(input_a, input_b);
			break;
		case "-":
			rslt = Operator.minus(input_a, input_b);
			break;
		case "*":
			rslt = Operator.mul(input_a, input_b);
			break;
		case "/":
			rslt = Operator.div(input_a, input_b);
			break;

		default:
			break;
		}
		Result.rslt(input_a, op, input_b, rslt);
	}

}
