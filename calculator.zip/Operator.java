package theD.begin.CAL;

public class Operator {
	public static int plus(int a, int b) {
		return a + b;

	}

	public static int minus(int a, int b) {
		return a - b;

	}

	public static int mul(int a, int b) {
		return a * b;

	}

	public static int div(int a, int b) {
		return a / b;

	}

}
