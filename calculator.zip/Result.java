
package theD.begin.CAL;

public class Result {
	public static void rslt(int a, String op, int b, int c) {
		System.out.println("*** ���� ��� ***");
		System.out.println(a + " " + op + " " + b + " = " + c);
	}

}
